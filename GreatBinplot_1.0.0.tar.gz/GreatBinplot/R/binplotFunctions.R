#' Draw scatterplot  -<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>-
#'
#' @param x a numeric vector, presented as x-axis
#' @param y a numeric vector of the same length of x, presented as y-axis
#' @return a scatter plot
#' @export
scatter <- function(x,y)
{
  plot(x,y,main="Raw Scatter Plot")
}




#' Draw 2d binplot -<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>-
#'
#' @param x a numeric vector, presented as x-axis
#' @param y a numeric vector of the same length of x, presented as y-axis
#' @param res a single numeric value. res defines the grid number for x-axis and y-axis.
#' @param raw a single logic value, false by default. If TRUE, draw scatterplot instead.
#' @return an "image" binplot output
#' @export
binplot <- function(x,y,res,raw=FALSE) {
  nc <- res
  nr <- res
  if (raw == TRUE){
    scatter(x,y)
  }
  zx = c(1:nr,rep(1,nc),1+trunc( nr*(x- min(x))/(max(x)-min(x)) ))
  zx[zx>nr] = nr
  zy = c(rep(1,nr),1:nc,1+trunc( nc*(y- min(y))/(max(y)-min(y)) ))
  zy[zy>nc] = nc
  z = table(zx,zy); z[,1]=z[,1]-1; z[1,]=z[1,]-1;
  image(z=t(z),x=seq(length=nr+1,from=min(x),to=max(x)),
        y= seq(length=nc+1,from=min(y),to=max(y)),
        xlab="",ylab="", col=topo.colors(100),main="binned scatter plot")
}




#' Draw 3D binplot -<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>--<>-
#'
#' @param x a numeric vector, presented as x-axis
#' @param y a numeric vector of the same length of x, presented as y-axis
#' @param res a single numeric value. res defines the grid number for x-axis and y-axis.
#' @param raw a single logic value, FALSE by default. If TRUE, draw scatterplot instead.
#' @param bin a single logic value, FALSE by default. If TRUE, draw 2D binplot.
#' @return a 3-D binplot
#' @export
TDbinplot <- function (x,y,res,raw=FALSE,bin=FALSE){
  library(plot3D)
  if (raw == TRUE) {
    scatter(x,y)
  }
  if (bin == TRUE) {
    binplot(x,y,res,FALSE)
  }
  xc <- cut(x,res)
  yc <- cut(y,res)
  z = table(xc,yc)
  hist3D(z=z, border="black",main="3D binned scatter plot")
}
